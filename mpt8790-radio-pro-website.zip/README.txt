MPT8790 RADIO — FREE WEBSITE

1. Upload index.html to a public GitHub repository.
2. GitHub: Settings > Pages > Deploy from branch > main > / (root).
3. Save and use the generated github.io address.

Live stream:
https://mpt.volticast.net/mpt

Before publishing, replace the # links in index.html with your real WhatsApp,
Instagram and Facebook URLs.
